<div class="d-none" id="nuevo-editar"></div>

<div id="contratos">

	<table id="tabla" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>Id_Contrato</th>
				<th>Id_Proceso</th>
				<th>Tipo_de_Contrato</th>
				<th>Empleado_Resposable</th>
				<th>Empresa_Perteneciente</th>
                <th>Fecha_Creacion</th>
                <th>Fecha_Expiracion</th>
			</tr>
		</thead>
		<tbody></tbody>

	</table>

	<script src="../js/funciones_fechas.js"></script>

</div>