<div class="d-none" id="nuevo-editar"></div>

<div id="sucursal">

	<button class="btn btn-primary mb-4" id="nuevo">Nuevo</button>
	<a href="./fpdf/sucursal_informe.php" target="_blank" class="btn btn-info mb-4" id="pdf">Lista de Sucursales</a>

	<table id="tabla" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>Id_Sucursal</th>
				<th>Empresa</th>
				<th>Ciudad</th>
				<th>Nombre_Sucursal</th>
				<th>Opciones</th>
			</tr>
		</thead>
		<tbody></tbody>

	</table>

	<script src="../js/funciones_sucursal.js"></script>

</div>