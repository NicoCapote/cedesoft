<div class="d-none" id="nuevo-editar"></div>

<div id="usuarios">

	<button class="btn btn-primary mb-4" id="nuevo">Nuevo</button>
	<a href="./fpdf/usuario_informe.php" target="_blank" class="btn btn-info mb-4" id="pdf">Lista de Usuarios</a>

	<table id="tabla" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>Id_Usuario</th>
				<th>Usuario</th>
				<th>Contraseña</th>
				<th>Correo</th>
				<th>Rol_Asignado</th>
                <th>Empleado</th>
                <th>Opciones</th>
			</tr>
		</thead>
		<tbody></tbody>

	</table>

	<script src="../js/funciones_usuario.js"></script>

</div>